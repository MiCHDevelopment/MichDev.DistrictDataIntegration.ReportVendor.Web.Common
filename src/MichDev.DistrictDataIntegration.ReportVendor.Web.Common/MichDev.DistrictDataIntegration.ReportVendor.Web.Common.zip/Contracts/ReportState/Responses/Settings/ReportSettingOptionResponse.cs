using System.Collections.Generic;

namespace MichDev.DistrictDataIntegration.ReportVendor.Web.Common.Contracts.ReportState.Responses.Settings
{
  public class ReportSettingOptionResponse
  {
    public string DisplayName { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
  }
}