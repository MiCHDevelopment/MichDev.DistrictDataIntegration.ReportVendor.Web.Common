namespace MichDev.DistrictDataIntegration.ReportVendor.Web.Common.Contracts.ReportNavigation.Responses
{
  public class ReportResponse : ReportNavigationTreeNodeResponse
  {
  }
}